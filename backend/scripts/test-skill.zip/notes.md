﻿hello from notes.md

